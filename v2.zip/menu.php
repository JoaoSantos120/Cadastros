<ul class="list-unstyled components">
                    <p>Personalizando o site de acordo com as escolhas do visitante!</p>
                    <li class="active">
                        <a href="#sub1" data-toggle="collapse" aria-expanded="false">Menu do Topo</a>
                        <ul class="collapse list-unstyled" id="sub1">
                            <li><a href="#">Preto</a></li>
                            <li><a href="#">Laranja</a></li>
                            <li><a href="#">Branco</a></li>
                        </ul>
                    </li>
                    <li>                        
                        <a href="#sub2" data-toggle="collapse" aria-expanded="false">Background</a>
                        <ul class="collapse list-unstyled" id="sub2">
                            <li><a href="#">Cinza</a></li>
                            <li><a href="#">Azul</a></li>
                            <li><a href="#">Branco</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#">Item novo</a>
                    </li>
                    <li>
                        <a href="#">Item novo..</a>
                    </li>
                </ul>